#!/bin/bash
#
#  dncat-linux-uninstall.sh
#  ------------------------
#  DotnetCat uninstaller script for ARM64 and x64 Linux systems
#