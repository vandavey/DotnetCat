<#
.SYNOPSIS
    DotnetCat uninstaller script for x64 and x86 Windows systems.
.DESCRIPTION
    DotnetCat remote command-shell application uninstaller script
    for x64 and x86 Windows systems.
.LINK
    Application repository: https://github.com/vandavey/DotnetCat
#>
using namespace System.Runtime.InteropServices
using namespace System.Security.Principal

[CmdletBinding()]
param ()

# Write an error message to stderr and exit
function Show-Error {
    $Symbol = "[x]"

    if ($PSVersionTable.PSVersion.Major -ge 7) {
        $Symbol = "`e[91m${Symbol}`e[0m"
    }
    [Console]::Error.WriteLine("${Symbol} ${args}`n")
    exit 1
}

# Write a status message to stdout
function Show-Status {
    $Symbol = "[*]"

    if ($PSVersionTable.PSVersion.Major -ge 7) {
        $Symbol = "`e[96m${Symbol}`e[0m"
    }
    Write-Output "${Symbol} ${args}"
}

# Uninstaller only supports Windows operating systems
if (-not [RuntimeInformation]::IsOSPlatform([OSPlatform]::Windows)) {
    Show-Error "This installer can only be used on Windows operating systems"
}
$User = [WindowsPrincipal]::new([WindowsIdentity]::GetCurrent())

# Uninstaller requires admin privileges
if (-not $User.IsInRole([WindowsBuiltInRole]::Administrator)) {
    Show-Error "The installer must be run as an administrator"
}
